// main.c
// Runs on LM3S1968
#include "GPIO.h"
#include "SYSCTL.h"
#include "SSI.h"
#include "I2C.h"
#include "regop.h"

#define WREN 0x06

void mcpyI2C_SPI(unsigned char src, unsigned char n, unsigned char dst);
void mcpySPI_I2C(unsigned char src, unsigned char n, unsigned char dst);

int main(void)
{
	//enable clocks
	//enable I2C clock
	sysctl_enableRCGC(RCGC1, 0x1000);
	
	//enable SSI0 clock
	sysctl_enableRCGC(RCGC1, 0x0010);
	
	//enable GPIO clocks (GPIO[A,B])
	sysctl_enableRCGC(RCGC2, 0x0003);
	
	//configure GPIOs
	//A2->SSI0CLK, A3->disabled, A4->SSI0Rx, A5->SSI0Tx,
	//gpio_initDigital(GPIOA, 0x08, 0x24);
	gpio_initAF(GPIOA, 0x34, 0x00);
	
	//B0->SSI /CS (manual control)
	//B2->I2C0SCL, B3->I2C0SDA
	gpio_initDigital(GPIOB, 0x00, 0x07);
	gpio_initAF(GPIOB, 0x06, 0x00);
	
	orWriteReg(GPIOB, GPIODATA, 0x01);
	
	//configure comms
	//init SSI0
	ssi_config(SSI0, 0x107, 0x0000, 0x00, 0x06);
	
	//init I2C
	i2c_config(I2C0, 0x5);
	
	//begin app
	while(1);
	
}

void mcpyI2C_SPI(unsigned char src, unsigned char n, unsigned char dst)
{
	unsigned char transferBuffer[256];
	int i = 0;

	//get data from I2C module
	transferBuffer[0]=src;
	
	//transmit address to read from
	i2c_tx(I2C0, 0x2A, transferBuffer, 1);
	
	//burst read
	i2c_rx(I2C0, 0x2A, transferBuffer, n);
	
	//put data to spi module
	
	//send write enable
	andWriteReg(GPIOB, GPIODATA, 0xFE);
	ssi_transfer(SSI0, WREN);
	orWriteReg(GPIOB, GPIODATA, 0x01);
	
	for(i = 0; i < n; i++)
	{
		andWriteReg(GPIOB, GPIODATA, 0xFE);
		//transmit address
		ssi_transfer(SSI0, 0x00); //9th bit (always 0)
		ssi_transfer(SSI0, dst+i);
		
		//transmit data
		ssi_transfer(SSI0, transferBuffer[i]);
		orWriteReg(GPIOB, GPIODATA, 0x01);
		
	}
	
}

void mcpySPI_I2C(unsigned char src, unsigned char n, unsigned char dst)
{
	unsigned char transferBuffer[256];
	int i = 0;
	
	//get data from SSI module
	for(i = 0; i < n; i++)
	{
		//transmit address
		andWriteReg(GPIOB, GPIODATA, 0xFE);
		ssi_transfer(SSI0, 0x00); //transfer 9th bit
		ssi_transfer(SSI0, src+i);
		
		//recieve data
		transferBuffer[i] = ssi_transfer(SSI0, 0x00);
		orWriteReg(GPIOB, GPIODATA, 0x01);
		
	}
	
	//send data
	i2c_tx(I2C0, 0x2A, transferBuffer, n);
	
}
