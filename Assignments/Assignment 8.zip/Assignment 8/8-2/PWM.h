//PWM.h

#ifndef PWM_H
#define PWM_H

#define PWMCTL			0x000
#define	PWMSYNC			0x004
#define PWMENABLE		0x008
#define PWMINVERT		0x00C
#define PWMFAULT		0x010
#define PWMINTEN		0x014
#define PWMRIS			0x018
#define PWMISC			0x01C
#define PWMSTATUS		0x020
#define PWM0CTL			0x040
#define PWM0ITEN		0x044
#define	PWM0RIS			0x048
#define PWM0ISC			0x04C
#define PWM0LOAD		0x050
#define PWM0COUNT		0x054
#define PWM0CMPA		0x058
#define PWM0CMPB		0x05C
#define PWM0GENA		0x060
#define PWM0GENB		0x064
#define PWM0DBCTL		0x068
#define PWM0DBRISE	0x06C
#define PWM0DBFALL	0x070
#define PWM1CTL			0x080
#define PWM1ITEN		0x084
#define	PWM1RIS			0x088
#define PWM1ISC			0x08C
#define PWM1LOAD		0x090
#define PWM1COUNT		0x094
#define PWM1CMPA		0x098
#define PWM1CMPB		0x09C
#define PWM1GENA		0x0A0
#define PWM1GENB		0x0A4
#define PWM1DBCTL		0x0A8
#define PWM1DBRISE	0x0AC
#define PWM1DBFALL	0x0B0
#define PWM2CTL			0x0C0
#define PWM2ITEN		0x0C4
#define	PWM2RIS			0x0C8
#define PWM2ISC			0x0CC
#define PWM2LOAD		0x0D0
#define PWM2COUNT		0x0D4
#define PWM2CMPA		0x0D8
#define PWM2CMPB		0x0DC
#define PWM2GENA		0x0E0
#define PWM2GENB		0x0E4
#define PWM2DBCTL		0x0E8
#define PWM2DBRISE	0x0EC
#define PWM2DBFALL	0x0F0

#define PWM ((unsigned char*)0x40028000)

#endif
