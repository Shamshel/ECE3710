// main.c
// Runs on LM3S1968
#include "PWM.h"
#include "GPIO.h"
#include "SYSCTL.h"
#include "regop.h"

void enableStepperMotor();
void disableStepperMotor();

int main(void)
{	
	//PWM0A = A
	//PWM0B = A'
	//PWM1A = B
	//PWM1B = B'
	//(see lecture 32 slides pg. 3)
	
	//enable PWM clock
	sysctl_enableRCGC(RCGC0, 0x00100000);
		
	//enable GPIOD and GPIOG clock
	//PWM0 is on G2. PWM1 is on D1
	//PWM2 is on H0. PWM3 is on H1.
	sysctl_enableRCGC(RCGC2, 0xA8);
	
	//configure GPIOs
	gpio_initAF(GPIOG, 0x04, 0x00);
	gpio_initAF(GPIOD, 0x02, 0x00);
	gpio_initAF(GPIOH, 0x03, 0x00);
	
	//configure RCC to enable PWM clock
	sysctl_enableRCGC(RCC, 0x100000);
	
	//configure for countdown with immediate updates
	writeReg(PWM, PWM0CTL, 0x00);
	writeReg(PWM, PWM0GENA, 0x08C);
	writeReg(PWM, PWM0GENB, 0x08C);
	
	writeReg(PWM, PWM1CTL, 0x00);
	writeReg(PWM, PWM1GENA, 0x08C);
	writeReg(PWM, PWM1GENB, 0x08C);
	
	//invert outputs 1 and 3
	writeReg(PWM, PWMINVERT, 0x0A);
	
	//set the period
	//2000 revs/1m = 60s/2000 revs = 0.03 s/rev
	//12,000,000 cycles/s * 0.03s = 360000 cycles
	//PWMDIV = 2
	//360000/2 = 180000 cycles = 0x2BF20
	writeReg(PWM, PWM0LOAD, 0x2BF20);
	writeReg(PWM, PWM1LOAD, 0x2BF20);
	
	//load compare values, 50% duty cycle
	writeReg(PWM, PWM0CMPA, 0x15F90);
	writeReg(PWM, PWM0CMPB, 0x15F90);
	writeReg(PWM, PWM1CMPA, 0x15F90);
	writeReg(PWM, PWM1CMPB, 0x15F90);
	
	//enable PWM outputs
	writeReg(PWM, PWMENABLE, 0x0F);
	
	enableStepperMotor();
	
	while(1);
	
}


void enableStepperMotor()
{
	int i = 0, dummy = 0;
	
	//enable PWM0
	writeReg(PWM, PWM0CTL, 0x01);
	
	
	//wait half a period
	for(i = 0; i < 0x15F90; i++)
	{
		dummy++;
		
	}
	
	writeReg(PWM, PWM1CTL, 0x01);
	
}

void disableStepperMotor()
{
	//disable pwms
	writeReg(PWM, PWM0CTL, 0x00);
	writeReg(PWM, PWM1CTL, 0x00);
	
}
