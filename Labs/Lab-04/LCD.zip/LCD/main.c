#include "LCD.H"

int main(void)
{
	//your code here.
	lcdInit();
	//exit success
	return 0;
}
